#include "huffman.h"
#include <cstddef>
#include <fstream>
#include <iostream>

#define SPACE 10
huffman::huffman() {
	head = NULL;
}

huff_node* huffman::get_head() {
	return head;
}

void huffman::sort_linkedlist() {
	huff_node* current = head;
	huff_node* index=head;
	int temp = 0;
	int temp2 = 0;
	if (head == NULL) {
		return;
	}
	else {
		while (current != NULL) {  

			while (index != NULL) { 
				if (current->count < index->count) {
					std::swap(current->data, index->data);
					std::swap(current->count, index->count);
				}
				index = index->next;
			}
			current = current->next;
			index = head;
		}
	}
}


void huffman::append_linkedlist(char ch) {
	if (head == NULL) {
		head = new huff_node;
		head -> data = ch;
		head->count++;
	}
	else {
		huff_node* current = head;
		huff_node* newnode = new huff_node;
		newnode->data = ch;
		newnode->count++;
		while (current->next != NULL) {
			current = current->next;
		}
		current->next = newnode;
	}
}

void huffman::create_huffman_linklist(char ch) {
	huff_node* current;
	current = head;
	while (current != NULL) {
		if (ch == current->data) {
			current->count++;
			return;
		}
		current = current->next;
	}
	append_linkedlist(ch);
}

void huffman::print2D(huff_node* r, int space) {
	if (r == NULL) // Base case  1
		return;
	space += SPACE;
	print2D(r->right, space);
	std::cout << std::endl;
	for (int i = SPACE; i < space; i++)
		std::cout << " ";
	    std::cout << r->data << ", "<<r->count<<"\n";
	    print2D(r->left, space);
}

void huffman::create_huffman_tree(std::string paragraph) {
	for (int i = 0; i < paragraph.length(); i++) {
		create_huffman_linklist(paragraph[i]);
	}
	sort_linkedlist();
	while (head->next != NULL) {
		priority_insert(make_node_for_huffman_tree());
	}

}

void huffman::delete_at_begin(int x) {
	huff_node *curr;
	for (int i = 0; i < x; i++) {
		curr = head;
		head = head->next;
		delete curr;
	}
}

huff_node* huffman::make_node_for_huffman_tree() {
	huff_node* temp1 = head, * temp2 = head->next, * temp3 = new huff_node;
	head = head->next->next;
	temp1->next = NULL;
	temp2->next = NULL;
	temp3->count = temp1->count + temp2->count;
	if (temp1->count <= temp2->count) {
		temp3->left = temp1;
		temp3->right = temp2;
	}
	else {
		temp3->left = temp2;
		temp3->right = temp1;
	}
	return temp3;
}

void huffman::priority_insert(huff_node *newnode) {
	huff_node* pre = NULL, * curr = head;

	if (head == NULL) {
		curr = newnode;
		head = newnode;
		return;
	}

	while (curr->count <= newnode->count) {
		pre = curr;
		curr = curr->next;
		if (curr == NULL) {
			break;
		}
	}
	newnode->next = curr;
	if (pre != NULL) {
		pre->next = newnode;
	}
	else {
		head = newnode;
	}
	return;
}

void huffman::encode(std::string words) {
	std::ofstream out;
	huff_node* iter = head;
	out.open("huffman_encode.txt");
	std::string path = "", temp = "";
	bool flag = 1;
	for (int i = 0; i < words.length(); i++) {
	find_path(iter, words[i], path, flag, temp);
		flag = 1;
		out << path;
	}
}

void huffman::find_path(huff_node* root, char& ch, std::string& path, bool& flag, std::string temp) {
	if (!flag) {
		return;
	}
	if (root->data != ch) {
		if (root->left != NULL) {
			find_path(root->left, ch, path, flag, temp + '0');
		}
		if (root->right != NULL) {
			find_path(root->right, ch, path, flag, temp + '1');
		}
	}
	else {
		path = temp;
		temp = "";
		flag = 0;
		return;
	}
	return;
}
void huffman::decode(std::ifstream& in, huff_node* iter) {
	std::ofstream out("after_decode.txt");
	char temp;
	while (!in.eof()) {
		temp = in.get();
		if (temp == '0') {
			iter = iter->left;
			if (iter->left == NULL && iter->right == NULL) {
				out << iter->data;
				iter = head;
			}
		}
		else {
			iter = iter->right;
			if (iter->left == NULL && iter->right == NULL) {
				out << iter->data;
				iter = head;
			}
		}
	}
}