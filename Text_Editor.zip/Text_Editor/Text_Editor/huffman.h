#pragma once
#include "huff_node.h"
#include <string>
#include <fstream>

class huffman {
	huff_node* head;

public:
	huffman();
	huff_node* get_head();
	void create_huffman_tree(std::string paragraph);
	void create_huffman_linklist(char ch);
	void append_linkedlist(char ch);
	void sort_linkedlist();
	void priority_insert(huff_node* newnode);
	void delete_at_begin(int x = 1);
	huff_node* make_node_for_huffman_tree();
	void encode(std::string words);
	void find_path(huff_node* root, char& ch, std::string& path, bool& flag, std::string temp);
	void print2D(huff_node* r, int space);
	void decode(std::ifstream& in, huff_node* iter);
};