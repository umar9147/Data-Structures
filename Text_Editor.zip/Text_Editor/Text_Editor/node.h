#pragma once
#include <string>

struct node {
	std::string data;
	node* child[26];
	bool flag;

	node();

};
