#include <iostream>
#include "Tree.h";
#include "huffman.h"
#include <windows.h>
#include <fstream>
#include <sstream>
using namespace std;

void print_suggestions(string arr[], int count);
void move_cursor_to_xy(int x, int y);
int select_suggestion(int count);
void load_data(string& typed_word, ifstream& in);
//void enter_data(string& typed_word, string& suggest_word, Tree& tree, string suggestion[], int& suggestion_size, ofstream& out);

int main() {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	bool flag = 1;
	ofstream out;
	ifstream in;
	string typed_word = "", suggest_word = "";
	Tree tree;
	string suggestion[10];
	int suggestion_size = 0;
	string choice = "\0";
	string logo = "*TEXT EDITOR By Umar Shahbaz!";
	SetConsoleTextAttribute(hConsole, 10);
	cout << "\n\n\n\n\t\t\t\t\t\t";
	for (int i = 0; i < logo.length(); i++)
	{
		Sleep(100);
		cout << logo[i];
	}
	cout << "\n\n\n\n\t\t\t\t\t\t";
	SetConsoleTextAttribute(hConsole, 11);
	cout << "Dictoinary File Is Loading Plz Wait For A Moment.......";
	tree.insert_outfile();
	start:
	system("cls");
	cout << "\n\n\n\n\n\n\n\t\t\t\t\t\t";
	SetConsoleTextAttribute(hConsole, 12);
	cout << "1 - Enter new data\n\n\t\t\t\t\t\t";
	SetConsoleTextAttribute(hConsole, 10);
	cout << "2 - Load previous data\n\n\t\t\t\t\t\t";
	SetConsoleTextAttribute(hConsole, 11);
	cout << "Enter Your Choice : ";
	cin >> choice;
	SetConsoleTextAttribute(hConsole, 15);
	if ((choice == "1" || choice == "2"))
	{
		if (choice == "2") {
			load_data(typed_word, in);
		}
		else {
			system("cls");
			cout << typed_word;
		}
	}
	else
	{
		cout << "Invalid Input!\n";
		cout << "Wait for Your next Attepmt!";
		Sleep(1000);
		goto start;
	}


	while (1) {
		if (GetAsyncKeyState(0x41)) {
			typed_word = typed_word + 'a';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x41)) {}
		}
		if (GetAsyncKeyState(0x42)) {
			typed_word = typed_word + 'b';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x42)) {}
		}
		if (GetAsyncKeyState(0x43)) {
			typed_word = typed_word + 'c';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x43)) {}
		}
		if (GetAsyncKeyState(0x44)) {
			typed_word = typed_word + 'd';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x44)) {}
		}
		if (GetAsyncKeyState(0x45)) {
			typed_word = typed_word + 'e';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x45)) {}
		}
		if (GetAsyncKeyState(0x46)) {
			typed_word = typed_word + 'f';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x46)) {}
		}
		if (GetAsyncKeyState(0x47)) {
			typed_word = typed_word + 'g';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x47)) {}
		}
		if (GetAsyncKeyState(0x48)) {
			typed_word = typed_word + 'h';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x48)) {}
		}
		if (GetAsyncKeyState(0x49)) {
			typed_word = typed_word + 'i';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x49)) {}
		}
		if (GetAsyncKeyState(0x4A)) {
			typed_word = typed_word + 'j';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x4A)) {}
		}
		if (GetAsyncKeyState(0x4B)) {
			typed_word = typed_word + 'k';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x4B)) {}
		}
		if (GetAsyncKeyState(0x4C)) {
			typed_word = typed_word + 'l';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x4C)) {}
		}
		if (GetAsyncKeyState(0x4D)) {
			typed_word = typed_word + 'm';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x4D)) {}
		}
		if (GetAsyncKeyState(0x4E)) {
			typed_word = typed_word + 'n';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x4E)) {}
		}
		if (GetAsyncKeyState(0x4F)) {
			typed_word = typed_word + 'o';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x4F)) {}
		}
		if (GetAsyncKeyState(0x50)) {
			typed_word = typed_word + 'p';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x50)) {}
		}
		if (GetAsyncKeyState(0x51)) {
			typed_word = typed_word + 'q';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x51)) {}
		}
		if (GetAsyncKeyState(0x52)) {
			typed_word = typed_word + 'r';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x52)) {}
		}
		if (GetAsyncKeyState(0x53)) {
			typed_word = typed_word + 's';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x53)) {}
		}
		if (GetAsyncKeyState(0x54)) {
			typed_word = typed_word + 't';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x54)) {}
		}
		if (GetAsyncKeyState(0x55)) {
			typed_word = typed_word + 'u';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x55)) {}
		}
		if (GetAsyncKeyState(0x56)) {
			typed_word = typed_word + 'v';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x56)) {}
		}
		if (GetAsyncKeyState(0x57)) {
			typed_word = typed_word + 'w';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x57)) {}
		}
		if (GetAsyncKeyState(0x58)) {
			typed_word = typed_word + 'x';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x58)) {}
		}
		if (GetAsyncKeyState(0x59)) {
			typed_word = typed_word + 'y';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x59)) {}
		}
		if (GetAsyncKeyState(0x5A)) {
			typed_word = typed_word + 'z';
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(0x5A)) {}
		}
		if (GetAsyncKeyState(VK_SPACE)) {
			typed_word = typed_word + ' ';
			suggest_word = "";
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(VK_SPACE)) {}
		}
		if (GetAsyncKeyState(VK_BACK)) {
			if (typed_word != "") {
				typed_word.pop_back();
			}
			system("cls");
			cout << typed_word;
			while (GetAsyncKeyState(VK_BACK)) {}
		}
		if (GetAsyncKeyState(VK_TAB)) {
			suggest_word = "";
			bool flag = 1;
			for (int i = typed_word.length() - 1; typed_word[i] != ' ' && flag; i--) {
				if (i == 0) {
					suggest_word.push_back(typed_word[i]);
					i++;
					flag = 0;
				}
				else
				{
					suggest_word.push_back(typed_word[i]);
				}
			}
			flag = 1;
			reverse(suggest_word.begin(), suggest_word.end());
			int selected;
			node* iter = tree.getroot();
			if (tree.present(suggest_word)) {
				tree.Get_suggestion(iter, suggest_word, suggestion, suggestion_size, flag);
				system("cls");
				print_suggestions(suggestion, suggestion_size);
				selected = select_suggestion(suggestion_size);
				bool cond = 1;
				if (selected >= 0 && selected < suggestion_size) {
					suggest_word = suggestion[selected];
					for (int j = (typed_word.length() - 1); typed_word[j] != ' ' && cond; j--) {
						if (j == 0)
						{
							typed_word.pop_back();
							j++;
							cond = 0;
						}
						else
							typed_word.pop_back();

					}
					cond = 1;
					for (int i = 0; i < suggest_word.length(); i++) {
						typed_word.push_back(suggest_word[i]);
					}
					system("cls");
					typed_word.push_back(' ');
					cout << typed_word;
				}
				else {
					system("cls");
					cout << typed_word;
				}

			}
			else {
				system("cls");
				cout << "No Suggestions \n";
				Sleep(2000);
				system("cls");
				cout << typed_word;
			}

			suggestion_size = 0;
			while (GetAsyncKeyState(VK_TAB)) {}
		}
		if (GetAsyncKeyState(VK_RSHIFT)) {
			out.open("Text.txt");
			out << typed_word;
			out.close();
			huffman obj;
			obj.create_huffman_tree(typed_word);
			obj.encode(typed_word);

			in.open("huffman_encode.txt");
			huff_node* iter = obj.get_head();
			obj.decode(in, iter);
			cout << "\n\n\n\n\t\t\t\t";
			string end = "Thanks For Using Our Services!";
			SetConsoleTextAttribute(hConsole, 12);
			for (int i = 0; i < end.length(); i++)
			{
				Sleep(200);
				cout << end[i];
			}
			cout << "\n\n\n\n\t\t\t\t";
			SetConsoleTextAttribute(hConsole, 11);
			cout << "Press Any Key To Exit!";
			SetConsoleTextAttribute(hConsole, 15);
			cout << "\n\n\n\n\n\n";
			break;
		}
	}

	system("pause>0");
	//return 0;
}

//void enter_data(string& typed_word,string& suggest_word,Tree& tree,string suggestion[],int& suggestion_size,ofstream& out) {
//	
//}

int select_suggestion(int count) {
	int x = 0, y = 0;
	move_cursor_to_xy(x, y);
	while (1) {
		if (GetAsyncKeyState(VK_DOWN)) {
			if (y >= count) {
				y = 0;
			}
			else {
				y++;
			}
			move_cursor_to_xy(x, y);
		}
		if (GetAsyncKeyState(VK_UP)) {
			if (y <= 0) {
				y = count;
			}
			else {
				y--;
			}
			move_cursor_to_xy(x, y);
		}
		if (GetAsyncKeyState(VK_LSHIFT)) {
			break;
		}
	}
	return y;
}

void move_cursor_to_xy(int x, int y) {
	static HANDLE h = NULL;
	if (!h)
	{
		h = GetStdHandle(STD_OUTPUT_HANDLE);
	}
	COORD cordinates;
	cordinates.X = x;
	cordinates.Y = y;
	SetConsoleCursorPosition(h, cordinates);
	Sleep(200);
}

void print_suggestions(string arr[], int count) {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	int x = 0;
	for (int i = 0; i < count; i++) {
		cout << i + 1 << " - ";
		SetConsoleTextAttribute(hConsole, 11);
		cout << arr[i] << endl;
		SetConsoleTextAttribute(hConsole, 15);
		x = i;
	}
	SetConsoleTextAttribute(hConsole, 12);
	cout << x + 2 << " - BACK" << endl;
	SetConsoleTextAttribute(hConsole, 15);
}
void load_data(string& typed_word, ifstream& in) {
	in.open("Text.txt");
	char temp;
	while (!in.eof()) {
		temp = in.get();
		typed_word = typed_word + temp;
	}
	in.close();
	system("cls");
	cout << typed_word;
}