#include "Tree.h"

Tree::Tree() {
	root = new node;
}

node* Tree::getroot() {
	return root;
}

void Tree::insert_word(std::string word) {
	node* iter = root;
	for (int i = 0; i < word.length(); i++) {
		char ch = word[i];
		if (iter->child[ch - 'a'] == NULL) {
			iter->child[ch - 'a'] = new node;
			iter->child[ch - 'a']->data = iter->data + ch;
		}
		iter = iter->child[ch - 'a'];
	}
	iter->flag = true;
}

bool Tree::remove_me(node* root) {
	for (int i = 0; i < 26; i++) {
		if (root->child[i] != NULL) {
			return false;
		}
	}
	return true;
}

bool Tree::present(std::string word) {
	for (int i = 0; i < word.length(); i++) {
		if (word[i] < 97 || word[i]>122) {
			return false;
		}
	}

	if (root == NULL) {
		return false;
	}
	node* iter = root;
	for (int i = 0; i < word.length(); i++) {
		if (iter->child[word[i] - 'a'] == NULL) {
			return false;
		}
		iter = iter->child[word[i] - 'a'];
	}
	return true;
}

void Tree::print_roots(node* root) {
	if (root == NULL) {
		return;
	}
	std::cout << root->data << std::endl;
	for (int i = 0; i < 26; i++) {
		print_roots(root->child[i]);
	}

}

void Tree::Get_suggestion(node* iter, std::string word, std::string suggestion[], int& count, bool &f) {
	if ((remove_me(iter) && !iter->flag) || count == 10) {
		return;
	}
	
	if (f) {
		for (int i = 0; i < word.length(); i++) {
			iter = iter->child[word[i] - 'a'];
		}
		f = false;
	}
	
	
	if (iter != NULL) {
		if (iter->flag) {
			suggestion[count] = iter->data;
			count++;
		}

		for (int i = 0; i < 26; i++) {
			if (iter->child[i] != NULL) {
				Get_suggestion(iter->child[i], word, suggestion, count,f);
			}
		}
	}

	
	return;
}

void Tree::insert_outfile() {
	std::string word;
	std::ifstream in;
	in.open("Dictionary.txt");
	while (!in.eof()) {
		in >> word;
		insert_word(word);
	}

}
