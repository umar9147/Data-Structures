#include "huff_node.h"
#include <cstddef>

huff_node::huff_node() {
	data = '\0';
	left =  NULL;
	right = NULL;
	next = NULL;
	count = 0;
}

huff_node::huff_node(const huff_node& huff) {
	this->data = huff.data;
	this->left = huff.left;
	this->right = huff.right;
	this->next = NULL;
	this->count = huff.count;
}
