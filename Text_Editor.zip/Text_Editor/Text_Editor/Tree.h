#pragma once
#include "node.h"
#include <fstream>
#include <iostream>

class Tree {
	node* root;

public:
	Tree();
	node* getroot();
	void insert_word(std::string word);
	bool remove_me(node* root);// Return true or false to tell that the node is extra or not
	bool present(std::string word);
	void Get_suggestion(node* root, std::string word, std::string sugesstion[], int &count, bool &f);
	void print_roots(node* root);
	void insert_outfile();

};
