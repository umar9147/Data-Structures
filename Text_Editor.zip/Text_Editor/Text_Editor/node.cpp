#include "node.h"

node::node() {
	data = "";
	flag = false;
	for (int i = 0; i < 26; i++) {
		child[i] = NULL;
	}
}