#pragma once

struct huff_node {
	char data;
	huff_node* left;
	huff_node* right;
	huff_node* next;
	int count;

	huff_node();
	huff_node(const huff_node& huff);

};